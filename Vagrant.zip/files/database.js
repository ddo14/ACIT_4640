module.exports = {
    localUrl: 'mongodb://localhost/acit4640'
};